﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectFees
{
    public class States
    {
        public List<StateFee> ServiceAreaStateFees = new List<StateFee>();
        public decimal OutOfAreaFee { get; private set; }

        public States()
        {
            ServiceAreaStateFees.Add(new ProjectFees.StateFee("Washington", "WA", 8.99m));
            ServiceAreaStateFees.Add(new ProjectFees.StateFee("Oregon", "OR", 2.99m));
            ServiceAreaStateFees.Add(new ProjectFees.StateFee("California", "CA", 16.99m));
            ServiceAreaStateFees.Add(new ProjectFees.StateFee("Idaho", "ID", 3.99m));
            ServiceAreaStateFees.Add(new ProjectFees.StateFee("Nevada", "NV", 5.99m));
            ServiceAreaStateFees.Add(new ProjectFees.StateFee("Arizona", "AZ", 2.99m));
            ServiceAreaStateFees.Add(new ProjectFees.StateFee("Montana", "MT", 8.99m));
            ServiceAreaStateFees.Add(new ProjectFees.StateFee("Wyoming", "WY", 4.99m));
            ServiceAreaStateFees.Add(new ProjectFees.StateFee("Utah", "UT", 7.99m));
            ServiceAreaStateFees.Add(new ProjectFees.StateFee("Colorado", "CO", 2.99m));

            OutOfAreaFee = 49.99m;
        }

        public decimal GetFeeForState(string twoLetterCode)
        {
            var state = ServiceAreaStateFees.FirstOrDefault(fee => fee.TwoLetterCode.Equals(twoLetterCode.ToUpper()));
            return state != null ? state.Fee : OutOfAreaFee;
        }
    }
}
