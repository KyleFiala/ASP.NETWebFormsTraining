﻿using System.Web.UI;

namespace MyWebApplication.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}